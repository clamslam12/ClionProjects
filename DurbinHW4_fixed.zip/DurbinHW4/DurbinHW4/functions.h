//
// Created by clams on 3/4/2019.
//

#ifndef HW4_FUNCTIONS_H
#define HW4_FUNCTIONS_H





void menu();
int push();
void pop();
void empty(int n);
void index(int val);





#endif //HW4_FUNCTIONS_H
