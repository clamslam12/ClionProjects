//
// Created by clams on 4/3/2019.
//

#ifndef HW6_NEW_FUNCTIONS_H
#define HW6_NEW_FUNCTIONS_H
#include "bank.h"
#include <queue>
#include <stack>
using namespace std;

void do_stuff(queue<my_queue> &q, stack<int> track_prev_end);///main driver
void set_obj_data(my_queue& obj, char a, int s, int p);///set data for objects in queue

#endif //HW6_NEW_FUNCTIONS_H
